# LEAF: per-image results for re-checking the paper's comparisons

Raw results of *LEAF: Latency-Budgeted Efficient Planning with Attention Forecasts for Training-Free Token Reduction*
(Huynh Canh Vien, Phan Minh Nhat, Pham Nhat Khoa, Nguyen Van Hieu; submitted to Knowledge-Based Systems).
Code, released schedules, probe tables, latency models and the sealed configuration of every evaluated arm:
https://github.com/huynhcanhvien/LEAF.

This package holds what is needed to re-check every accuracy comparison and every timing of the paper **without
running any model**: the per-image correctness of each evaluated configuration, the raw latency measurements and the
analysis reports.

## Quick check (about one second)

```
python verify.py        # Python 3 and NumPy only
```

`verify.py` recomputes, from `correctness/`, the accuracy difference and the exact McNemar test of every latency pair,
applies Holm's correction over the pairs of a split, and compares the result with the reports:

| Comparison | Pairs | Splits | Paper |
|---|---|---|---|
| Main comparison, seven ImageNet classifiers | 79 (68 + 11 with the earlier variant) | val, V2, ReaL | Table 2, Supplementary S5.2 |
| ViT-B/16 at 384 pixels | 24 | val, V2 | Supplementary S5.11 |
| CLIP ViT-B/16 | 43 | val, V2, Flickr30k and MS-COCO R@1 (both directions) | Table 6 |

## Contents

| Path | Content |
|---|---|
| `correctness/<backbone>__<split>.npz` | One bit-packed array per evaluated configuration, keyed by its 16-hex `config_sha`. `np.unpackbits(a)[:n].astype(bool)` gives per-image correctness. Splits: `val` (ImageNet val, 50,000), `v2` (ImageNet-V2 matched-frequency, 10,000), `real` (ReaL labels, the 46,837 val images that have them), and for CLIP `flickr_test_i2t`/`_t2i` (1,000 images / 5,000 captions) and `coco_test_i2t`/`_t2i` (5,000 / 25,010): correct = Recall@1. |
| `runs_index.csv` | Every evaluated configuration: backbone, split, `config_sha`, number of images, top-1 (or R@1), and the experiments that evaluated it. Configurations are deterministic, so a configuration evaluated by several experiments is stored once. |
| `arm_names.csv` | Arm name → `config_sha` for the ViT-B/16-384 and CLIP comparisons (the main comparison's report carries the shas itself). |
| `timing/<experiment>/<backbone>/latency/*.json` | Raw timing records: one file per configuration and round, with that round's summary (mean, median and 90th percentile over its timed passes, throughput, peak memory) and the device. |
| `reports/<experiment>/...` | Analysis outputs of each experiment (pairings, McNemar/Holm tests, confidence intervals, fitted latency models, summaries). `reports/main_comparison_analysis/report_leaf.json` and `numbers_leaf.json` hold every number of the main comparison. |
| `verify.py` | The check above. |
| `MANIFEST.sha256` | SHA-256 of every file. |

Experiment folders follow the code repository (`leaf/reproduction/experiments/<name>.py`); its `results/README.md`
maps each folder to the paper.

## What is not included, and why

- Per-image results on the calibration images (the single-station probes, 5,000 training images): the planner uses
  them only through the probe tables, which are released in the code repository.
- The confirmation set, which is evaluated for every sealed configuration but selects nothing in the paper.
- Per-image KL divergences of the evaluation runs (their means are in the reports) and per-image predictions (the
  ReaL re-scoring is provided as `real` correctness).
- Sealed plans and schedules: in the code repository (`schedules/`).
- Development runs that the paper does not report.

The complete raw results (about 7 GB) are available from the corresponding author on request.

## Licence and citation

Data: Creative Commons Attribution 4.0 International (CC BY 4.0), see `LICENSE`. The `real` correctness is derived
from the ReaL labels of Beyer et al. (2020, https://github.com/google-research/reassessed-imagenet). Please cite the
paper and this dataset (DOI on the Zenodo record).
