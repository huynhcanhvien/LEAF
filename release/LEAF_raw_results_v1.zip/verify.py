"""Re-check the paired tests of the LEAF paper from the per-image correctness in this package.

For every latency pair in reports/, the script recomputes the accuracy difference and the exact McNemar p-value from
correctness/, applies Holm's correction over all pairs of a split, and compares the significant wins and losses with
the reported ones. It needs only Python 3 and NumPy and runs in a few seconds:

    python verify.py

Tests: main comparison (Table 2 of the paper, 79 pairs incl. 11 with the earlier variant; val, V2, ReaL),
ViT-B/16 at 384 pixels (24 pairs; Supplementary S5.11) and CLIP ViT-B/16 (43 pairs; Table 6).
"""
import csv
import json
from collections import defaultdict
from math import comb, erf, sqrt
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
NAMES = {'ToMe+M3': 'ToMe+MLERP', 'LEAF-M0': 'early LEAF'}
_cache = {}


def correct(backbone, split, sha):
    """Boolean per-image (or per-query) correctness of one evaluated configuration."""
    key = (backbone, split)
    if key not in _cache:
        _cache[key] = np.load(HERE / 'correctness' / f'{backbone}__{split}.npz')
    n = {'val': 50000, 'v2': 10000, 'real': 46837, 'flickr_test_i2t': 1000, 'flickr_test_t2i': 5000,
         'coco_test_i2t': 5000, 'coco_test_t2i': 25010}[split]
    return np.unpackbits(_cache[key][sha])[:n].astype(bool)


def mcnemar(a, b):
    """Exact-binomial McNemar p-value (normal approximation above 2000 discordant pairs), as in the paper's code."""
    n01 = int(np.sum(a & ~b)); n10 = int(np.sum(~a & b)); n = n01 + n10
    if n == 0: return 1.0
    if n > 2000:
        z = max(0, abs(n01 - n10) - 1) / sqrt(n)
        return 2 * (1 - 0.5 * (1 + erf(z / sqrt(2))))
    return min(1.0, 2 * sum(comb(n, i) for i in range(0, min(n01, n10) + 1)) / 2 ** n)


def holm(ps):
    order = sorted(range(len(ps)), key=lambda i: ps[i]); out = [0.0] * len(ps); run = 0.0
    for r, i in enumerate(order):
        run = max(run, min(1.0, (len(ps) - r) * ps[i])); out[i] = run
    return out


def check(title, pairs, splits, sha_of, backbone_of):
    """pairs: reported tests with ours/ref names and per-split dicts {delta, holm}."""
    print(f'\n== {title}: {len(pairs)} pairs')
    for s in splits:
        rows = [t for t in pairs if s in t]
        ds, ps = [], []
        for t in rows:
            bb = backbone_of(t)
            a, b = correct(bb, s, sha_of(t, 'ours')), correct(bb, s, sha_of(t, 'ref'))
            ds.append(100 * (a.mean() - b.mean())); ps.append(mcnemar(a, b))
        hs = holm(ps)
        agree = sum((h < .05) == (t[s]['holm'] < .05) and abs(d - t[s]['delta']) < 1e-6 for t, d, h in zip(rows, ds, hs))
        fam = defaultdict(lambda: [0, 0, 0])
        for t, d, h in zip(rows, ds, hs):
            f = fam[NAMES.get(t['family'], t['family'])]; f[0] += 1
            if h < .05: f[1 if d > 0 else 2] += 1
        wins = sum(f[1] for f in fam.values()); losses = sum(f[2] for f in fam.values())
        print(f'  {s:16s} recomputed W/L {wins}/{losses}; agrees with the report in {agree}/{len(rows)} pairs')
        if title.startswith('Main'):
            print('    ' + ', '.join(f'{k} {v[1]}/{v[2]} of {v[0]}' for k, v in sorted(fam.items())))


def main():
    rep = json.loads((HERE / 'reports/main_comparison_analysis/report_leaf.json').read_text())
    sha = {(bb, a['name']): a['sha'] for bb, arms in rep['arms'].items() for a in arms}
    real = json.loads((HERE / 'reports/imagenet_real/report.json').read_text())
    real_by = {(t['backbone'], t['ours'], t['ref']): t['real'] for t in real['tests']}
    tests = [dict(t, real=real_by[(t['backbone'], t['ours'], t['ref'])]) if (t['backbone'], t['ours'], t['ref']) in real_by else t
             for t in rep['tests']]
    check('Main comparison (Table 2)', tests, ('val', 'v2', 'real'),
          lambda t, side: sha[(t['backbone'], t[side])], lambda t: t['backbone'])

    names = {}
    with open(HERE / 'arm_names.csv') as fh:
        for r in csv.DictReader(fh): names[(r['backbone'], r['arm_name'])] = r['config_sha']
    for title, path, bb in [('ViT-B/16 at 384 pixels (Supplementary S5.11)', 'vitb384_comparison/augreg_b384/report.json', 'augreg_b384'),
                            ('CLIP ViT-B/16 (Table 6)', 'clip_comparison/clip_b16/report.json', 'clip_b16')]:
        r = json.loads((HERE / 'reports' / path).read_text())
        splits = [s for s in ('val', 'v2', 'flickr_test_i2t', 'flickr_test_t2i', 'coco_test_i2t', 'coco_test_t2i') if s in r['splits'] or s in ('val', 'v2')]
        check(title, r['latency_pairs'], splits, lambda t, side, bb=bb: names[(bb, t[side])], lambda t, bb=bb: bb)


if __name__ == '__main__':
    main()
